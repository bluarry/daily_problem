# 编译及运行说明
## 进入到qtclient 目录的myclient目录下，给run.sh权限777，然后执行run.sh即可编译成功客户端
```bash
sudo chmod 777 run.sh
./run.sh
```
## 致此客户端和服务器端已经编译成功，命令行端运行即可